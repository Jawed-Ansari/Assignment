//
//  postsTVCell.swift
//  codeITAssignment
//
//  Created by M Jawed Ansari on 12/06/22.
//

import UIKit

class postsTVCell: UITableViewCell {

    
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lbBody: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
       
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
