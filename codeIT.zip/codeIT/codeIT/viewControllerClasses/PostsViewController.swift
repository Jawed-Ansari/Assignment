//
//  PostsViewController.swift
//  codeITAssignment
//
//  Created by M Jawed Ansari on 12/06/22.
//

import UIKit
import CoreData

class PostsViewController: UIViewController,UITableViewDelegate,UITableViewDataSource
{
    
    let userInterface = UIDevice.current.userInterfaceIdiom
    let screenSize = UIScreen.main.bounds
    
    @IBOutlet weak var postTableview: UITableView!
    
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    var timer : Timer!
    var toastMessage:String!
    var postsData = [Posts_struct]()
    var detailsData = [postDetails_Struct]()
    
    var bodyData = [String]()
    var titleData = [String]()
    var userIdData = [Int]()
    var postIdData = [Int]()
    var nameData = [String]()
    var emailData = [String]()
    var detailIdData = [Int]()
    var entitiNameArray = ["Posts","DetailsData"]
    
    let dispatchGroups = DispatchGroup()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        postTableview.sectionHeaderHeight = 0
        
        timer = Timer.scheduledTimer(timeInterval: 300.0, target: self, selector: #selector(self.timeOutMethod), userInfo: nil, repeats: false)
        
        if Reachability.isConnectedToNetwork()
        {
            self.apiForPostsData()
            self.apiForDetailsData()
            
        }
        else
        {
            self.showSimpleAlert()
            
        }
        
        dispatchGroups.notify(queue: .main)
        {
            for i in 0..<self.entitiNameArray.count
            {
                self.getAllData(entityName: self.entitiNameArray[i])
            }
            
            self.postTableview.reloadData()
            SwiftLoader.hide()
        }
        
    }
    
    
    override func viewWillAppear(_ animated: Bool)
    {
        if UserDefaults.standard.bool(forKey: "DeleteManually") == true
        {
            self.autoRefresh()
            UserDefaults.standard.set(false, forKey: "DeleteManually")
        }
    }
    // MARK: - APIs calling
    
    func apiForPostsData()
    {
        dispatchGroups.enter()
        postsData.removeAll()
        SwiftLoader.show(title: "Loading...", animated: true)
        
        
        let urlString = "https://jsonplaceholder.typicode.com/posts"
        
        let session = URLSession.shared
        let url = URL(string: urlString)!
        var request = URLRequest(url: url)
        
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        
        session.dataTask(with: request, completionHandler: { [self] (data: Data?, response: URLResponse?, error: Error?) in
            guard let data = data else {return}
            //print("The response is : ",String(data: data, encoding: .utf8)!)
            
            do {
                
                let decoder = JSONDecoder()
                self.postsData = try decoder.decode([Posts_struct].self, from:
                                                        data) //Decode JSON Response Data
                print(postsData)
                
                
                for i in 0..<self.postsData.count
                {
                    let userId = self.postsData[i].userId!
                    let title = self.postsData[i].title!
                    let body = self.postsData[i].body!
                    let postId = self.postsData[i].id!
                    self.savingPostDataInLocal(userId: userId, postId: postId, title: title, body: body)
                    
                }
                
                dispatchGroups.leave()
                
            }catch let error {
                print(error.localizedDescription)
            }
        }).resume()
    }
    
    
    func apiForDetailsData()
    {
        dispatchGroups.enter()
        let urlString = "https://jsonplaceholder.typicode.com/users"
        
        let session = URLSession.shared
        let url = URL(string: urlString)!
        var request = URLRequest(url: url)
        
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        
        session.dataTask(with: request, completionHandler: { [self] (data: Data?, response: URLResponse?, error: Error?) in
            guard let data = data else {return}
            
            do {
                
                let decoder = JSONDecoder()
                self.detailsData = try decoder.decode([postDetails_Struct].self, from:
                                                        data)
                
                for i in 0..<self.detailsData.count
                {
                    let userId = self.detailsData[i].id!
                    let name = self.detailsData[i].name!
                    let email = self.detailsData[i].email!
                    
                    self.savingDetailDataInLocal(idNumber: userId, name: name, mail: email)
                    
                }
                
                dispatchGroups.leave()
                
            }catch let error {
                print(error.localizedDescription)
            }
        }).resume()
    }
    
    
    @objc func timeOutMethod()
    {
        DispatchQueue.global(qos: .background).async {
            for i in 0..<self.entitiNameArray.count
            {
                self.deleteAllRecordsFromCoreData(entityName: self.entitiNameArray[i])
            }
            DispatchQueue.main.async
            {
                self.postTableview.reloadData()
                self.toastMessage = "Time Out! Please Referesh"
                self.showToast()
            }
        }

        
    }
    
    
    // MARK: - Saving records into Core Data
    
    func savingPostDataInLocal(userId:Int,postId:Int ,title:String ,body:String)
    {
        
        
        let context = self.appDelegate.persistentContainer.viewContext
        let entity = NSEntityDescription.entity(forEntityName: "Posts", in: context)
        let newUser = NSManagedObject(entity: entity!, insertInto: context)
        
        newUser.setValue(userId, forKey: "userId")
        newUser.setValue(title, forKey: "title")
        newUser.setValue(body, forKey: "body")
        newUser.setValue(postId, forKey: "postId")
        
        do {
            try context.save()
            
            print("Succesfull")
            
        }
        catch
        {
            print("Error")
            
        }
        
    }
    
    func savingDetailDataInLocal(idNumber:Int ,name:String ,mail:String )
    {
        
        
        let context = self.appDelegate.persistentContainer.viewContext
        let entity = NSEntityDescription.entity(forEntityName: "DetailsData", in: context)
        let newUser = NSManagedObject(entity: entity!, insertInto: context)
        
        //DetailsData
        newUser.setValue(idNumber, forKey: "userId")
        newUser.setValue(name, forKey: "name")
        newUser.setValue(mail, forKey: "email")
        
        do {
            try context.save()
            
            print("Succesfull")
            
        }
        catch
        {
            print("Error")
            
        }
        
    }
    
   
    // MARK: - Manually Refresh post List
    
    @IBAction func tapToRefereshRecord(_ sender: Any)
    {
        SwiftLoader.show(title: "Loading...", animated: true)
        DispatchQueue.global(qos: .background).async {
            for i in 0..<self.entitiNameArray.count
            {
                self.getAllData(entityName: self.entitiNameArray[i])
            }
            DispatchQueue.main.async
            {
                self.postTableview.reloadData()
                SwiftLoader.hide()
                self.timer = Timer.scheduledTimer(timeInterval: 300.0, target: self, selector: #selector(self.timeOutMethod), userInfo: nil, repeats: false)
            }
            
        }
    }
    
    
    // MARK: - Fetch Data From Core Data
    
    func getAllData(entityName:String)
    {
        if entityName == "Posts"
        {
            titleData.removeAll()
            bodyData.removeAll()
            postIdData.removeAll()
            userIdData.removeAll()
            
            let context = appDelegate.persistentContainer.viewContext
            let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Posts")
            request.returnsObjectsAsFaults = false
            do {
                let result = try context.fetch(request)
                for data in result as! [NSManagedObject] {
                    let title = (data.value(forKey: "title") as! String)
                    let body = data.value(forKey: "body") as! String
                    let postId = data.value(forKey: "postId") as! Int
                    let userId = data.value(forKey: "userId") as! Int
                    
                    titleData.append(title)
                    bodyData.append(body)
                    postIdData.append(postId)
                    userIdData.append(userId)
                }
            } catch {
                
                print("Failed")
            }
        }
        else
        {
            emailData.removeAll()
            nameData.removeAll()
            detailIdData.removeAll()
            
            let context = appDelegate.persistentContainer.viewContext
            let request = NSFetchRequest<NSFetchRequestResult>(entityName: "DetailsData")
            request.returnsObjectsAsFaults = false
            do {
                let result = try context.fetch(request)
                for data in result as! [NSManagedObject] {
                    let email = (data.value(forKey: "email") as! String)
                    let name = data.value(forKey: "name") as! String
                    let userId = data.value(forKey: "userId") as! Int
                    
                    emailData.append(email)
                    nameData.append(name)
                    detailIdData.append(userId)
                }
            } catch {
                
                print("Failed")
            }
            
        }
    }
    
    // MARK: - Delete all Data From Core Data after complete time period
    
    func deleteAllRecordsFromCoreData(entityName:String)
    {
        let context = appDelegate.persistentContainer.viewContext
        let request = NSFetchRequest<NSFetchRequestResult>(entityName:entityName)
        request.returnsObjectsAsFaults = false
        do {
            let result = try context.fetch(request)
            if result.count > 0
            {
                let objectToDelete = result[0] as! NSManagedObject
                context.delete(objectToDelete)
                
                do
                {
                    try context.save()
                    
                    bodyData.removeAll()
                    titleData.removeAll()
                    userIdData.removeAll()
                    postIdData.removeAll()
                    nameData.removeAll()
                    emailData.removeAll()
                    detailIdData.removeAll()
                    
                }catch
                {
                    print(error)
                    toastMessage = "Some Error!!"
                    self.showToast()
                }
            }
            else
            {
                toastMessage = "There is no record found"
                self.showToast()
            }
            
        } catch
        {
            
            toastMessage = "Failed"
            self.showToast()
        }
        
    }
    
    
    // MARK: - Table View's  Data source and delegate methods
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return titleData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "postsTVCell") as! postsTVCell
        
        cell.lblTitle.text = titleData[indexPath.row]
        cell.lbBody.text = bodyData[indexPath.row]
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        if userInterface == .pad
        {
            return 120
        }
        else
        {
            return 80
        }
    }
    
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let nextview = self.storyboard?.instantiateViewController(withIdentifier: "DetailsViewController") as? DetailsViewController
        
        
        nextview?.titleName = titleData[indexPath.item]
        nextview?.selectedId = userIdData[indexPath.item]
        nextview?.bodyText = bodyData[indexPath.item]
        nextview?.postId = postIdData[indexPath.item]
        nextview?.emailData = emailData
        nextview?.nameData = nameData
        nextview?.detailIdData = detailIdData
        
        
        self.navigationController?.pushViewController(nextview!, animated: true)
        
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        headerView.backgroundColor = UIColor.clear
        return headerView
    }
    
    // MARK: - Auto Refresh data
    
    func autoRefresh()
    {
        SwiftLoader.show(title: "Loading...", animated: true)
        DispatchQueue.global(qos: .background).async {
            for i in 0..<self.entitiNameArray.count
            {
                self.getAllData(entityName: self.entitiNameArray[i])
            }
            DispatchQueue.main.async
            {
                self.postTableview.reloadData()
                SwiftLoader.hide()
            }
            
        }
    }
    
    
    // MARK: - Alert and Messages
    
    func showToast()
    {
        let alert = UIAlertController(title: nil, message: "", preferredStyle: .alert)
        
        let messageFont = [NSAttributedString.Key.font: UIFont(name: "ArialHebrew-Bold", size: 15.0)!]
        let messageAttrString = NSMutableAttributedString(string: toastMessage, attributes: messageFont)
        
        alert.setValue(messageAttrString, forKey: "attributedMessage")
        
        self.present(alert, animated: true, completion: nil)
        
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double((Int64)(2.0 * Double(NSEC_PER_SEC))) / Double(NSEC_PER_SEC), execute: {() -> Void in
            
            alert.dismiss(animated: true, completion: {() -> Void in
                
                
            })
            
        })
        
    }
    
    
    func showSimpleAlert()
    {
        let alert = UIAlertController(title: "No Internet Connection", message: "Make sure your device is connected to the Internet.Connect with Internet and restart App",         preferredStyle: UIAlertController.Style.alert)
        
        alert.addAction(UIAlertAction(title: "OK",
                                      style: UIAlertAction.Style.default,
                                      handler: {(_: UIAlertAction!) in
                                      
                                      }))
        self.present(alert, animated: true, completion: nil)
    }
    
    
}


