//
//  DetailsViewController.swift
//  codeITAssignment
//
//  Created by M Jawed Ansari on 12/06/22.
//

import UIKit
import CoreData

class DetailsViewController: UIViewController,UIGestureRecognizerDelegate {
    
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    var toastMessage:String!
    
    @IBOutlet weak var lblTitle: UILabel!
    
    @IBOutlet weak var bodyView: UILabel!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblMail: UILabel!
    
    var detailsData = [postDetails_Struct]()
    var selectedId:Int!
    var titleName:String!
    var bodyText:String!
    var postId:Int!
    
    var nameData = [String]()
    var emailData = [String]()
    var detailIdData = [Int]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        for i in 0..<nameData.count
        {
            let id = detailIdData[i]
            if selectedId == id
            {
                lblName.text = nameData[i]
                lblMail.text = emailData[i]
                lblTitle.text = titleName
                bodyView.text = bodyText
                
            }
        }
        
    }
    
    @IBAction func tapToBack(_ sender: Any)
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func tapToDeleteRecord(_ sender: Any)
    {
        deleteSelectedRecord(idNumber: postId)
    }
    
    func deleteSelectedRecord(idNumber:Int)
    {
        let context = appDelegate.persistentContainer.viewContext
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Posts")
        request.predicate = NSPredicate(format: "postId = %d", idNumber)
        request.returnsObjectsAsFaults = false
        do {
            let result = try context.fetch(request)
            if result.count > 0
            {
                let objectToDelete = result[0] as! NSManagedObject
                context.delete(objectToDelete)
                
                do
                {
                    try context.save()
                    
                    toastMessage = "Post Delete Successfully!"
                 
                    UserDefaults.standard.set(true, forKey: "DeleteManually")
                
                    self.showToast()
                    
                }catch
                {
                    print(error)
                    toastMessage = "Some Error!!"
                    self.showToast()
                }
            }
            else
            {
                toastMessage = "There is no record found"
                self.showToast()
            }
            
        } catch
        {
            
            toastMessage = "Failed"
            self.showToast()
        }
        
    }
    
    func showToast()
    {
        let alert = UIAlertController(title: nil, message: "", preferredStyle: .alert)
        
        let messageFont = [NSAttributedString.Key.font: UIFont(name: "ArialHebrew-Bold", size: 15.0)!]
        let messageAttrString = NSMutableAttributedString(string: toastMessage, attributes: messageFont)
        
        alert.setValue(messageAttrString, forKey: "attributedMessage")
        
        self.present(alert, animated: true, completion: nil)
        
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double((Int64)(2.0 * Double(NSEC_PER_SEC))) / Double(NSEC_PER_SEC), execute: {() -> Void in
            
            alert.dismiss(animated: true, completion: {() -> Void in
                
                self.navigationController?.popViewController(animated: true)
            })
            
        })
        
    }
}
